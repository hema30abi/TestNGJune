package com.testng.listeners;

import org.testng.Assert;
import org.testng.annotations.Test;

public class UnknownFailureTest {

	@Test
	public void testOne() {
		System.out.println("Unknown Fail Test");
		Assert.assertTrue(false);
	}
}
