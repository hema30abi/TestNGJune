package com.testng.listeners;

import org.junit.Assert;
import org.testng.annotations.Test;

public class KnownFailureTest {

	@Test(retryAnalyzer = RetryClass.class)
	public void knownFailure() {
		System.out.println("Known Failure Test");
		Assert.assertTrue(false); //accept only true
	}
}
