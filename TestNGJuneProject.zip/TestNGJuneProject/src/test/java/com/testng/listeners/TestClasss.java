package com.testng.listeners;

import org.testng.Assert;
import org.testng.annotations.Test;
//onStart
public class TestClasss {

	//onTestStart
	@Test
	public void methodOne() { //depends on result it can be onTestFailure() or onTestSuccess
		System.out.println("Test one"); //If the tc skipped, then it will move to onTestskipped()
		Assert.assertTrue(false);
	}
	
	//onFinish
}
