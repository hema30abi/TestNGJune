package com.testng.listeners;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryClass implements IRetryAnalyzer{

	int min = 0;// 0, 1, 2, 3, 4
	int max = 5;
	
	public boolean retry(ITestResult result) { //method will rerun the failed tc
		if(min<max) { //0<5
			min++;
			return true;
		}
		return false;
	}

}
